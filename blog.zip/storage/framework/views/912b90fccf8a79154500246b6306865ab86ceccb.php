

<img <?php echo e($attributes); ?> src="" alt=""><?php /**PATH C:\xampp\htdocs\blog\resources\views/vendor/jetstream/components/application-mark.blade.php ENDPATH**/ ?>