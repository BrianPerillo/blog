<?php if($search!=''): ?> <?php $placeholder=$search ?> <?php endif; ?>

<div class="col-md-12">

    <div class="row col-md-12 m-0 mb-3 d-flex justify-content-center">
            <form action="<?php echo e(route('dashboard.filtros')); ?>" class="col-md-3 mb-3" action="" method="get">
                
                <input id="search" class="col-md-12" type="text" style="border-radius:20px" name="search" 
                placeholder="<?php echo e($search); ?>" onchange="lowerCase()" value="" 
                >
            </form>
    </div>

    <!-- Dropdown Menu Filtros -->
    <div class="row col-md-12 m-0 mb-3 d-flex justify-content-center">
    
        <div class="hidden sm:flex col-md-12 p-0">
            <!-- Settings Dropdown -->
            <div class="relative col-md-12 p-0 d-flex justify-content-center">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dropdown_para_search','data' => ['align' => 'right','width' => '100']]); ?>
<?php $component->withName('dropdown_para_search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['align' => 'right','width' => '100']); ?>
                     <?php $__env->slot('trigger'); ?> 
                            <span class="inline-flex rounded-md">
                                <button type="button" class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 bg-white hover:text-gray-700 focus:outline-none transition ease-in-out duration-150">
                                    Más Filtros
                                    <svg class="ml-2 -mr-0.5 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                    </svg>
                                </button>
                            </span>
                     <?php $__env->endSlot(); ?>
                     <?php $__env->slot('content'); ?> 
                        <!-- Account Management -->
                        <div class="block px-4 py-2 text-xs text-gray-400">
                            Filtros
                        </div>
                        
                        <div class="row col-md-12 m-0 mb-5 d-flex justify-content-center">
                            
                        </div>

                     <?php $__env->endSlot(); ?>
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div>
        </div>
    </div>

</div>
    <?php /**PATH C:\xampp\htdocs\blog\resources\views/components/search-livewire.blade.php ENDPATH**/ ?>