<div>
    <div <?php echo e($attributes->merge(['class'=>"alert alert-$tipo alert-dismissible fade show"])); ?> role="alert">
        <strong><?php echo e($title); ?></strong> <?php echo e($slot); ?> <?php echo e($attributes['signo']); ?> <?php echo e($attributes['caracter']); ?> <?php echo e($txt()); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
</div><?php /**PATH C:\xampp\htdocs\blog\resources\views/components/alert.blade.php ENDPATH**/ ?>