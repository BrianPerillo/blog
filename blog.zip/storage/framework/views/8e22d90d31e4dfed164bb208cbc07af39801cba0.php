<div>

    <?php if(!isset($categoria)): ?> <?php echo e($categoria=''); ?> <?php endif; ?>

    <?php if(!isset($fecha)): ?> <?php echo e($fecha=''); ?> <?php endif; ?>

    <?php if(!isset($search)): ?> <?php $search='Buscar por Título, Autor, Categoría o Tag' ?> <?php endif; ?>

    <!-- Search -->
        <form wire:submit.prevent="filtrarSearch">
            <input type="text" wire:model="search">
        </form>

    <!-- Categorías -->
        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button type="submit" wire:click="filtrarCategoria('<?php echo e($categoria->name); ?>')"><p style="margin:0;padding:0" <?php if($categoria->name==''): ?> <?php echo e('class=font-weight-bold'); ?> <?php endif; ?>><?php echo e($categoria->name); ?></button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Fecha -->
        <button type="submit" wire:click="filtrarFecha('desc')"><p style="margin:0;padding:0" <?php if($categoria->name==''): ?> <?php echo e('class=font-weight-bold'); ?> <?php endif; ?>>Mas recientes</button>
        <button type="submit" wire:click="filtrarFecha('asc')"><p style="margin:0;padding:0" <?php if($categoria->name==''): ?> <?php echo e('class=font-weight-bold'); ?> <?php endif; ?>>Mas antiguos</button>
    
    <!-- Results -->
    <br><br>
    <?php if(isset($posts)): ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($post->name); ?> <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    

</div>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/livewire/buscador-test.blade.php ENDPATH**/ ?>