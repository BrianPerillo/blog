<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <body>
        <div class="col-md-12 "><br>
            <form action="<?php echo e(route('posts.update', $post)); ?>" method="POST">

                <?php echo method_field('put'); ?>

                <?php echo csrf_field(); ?>
               
                <div class="form-group col-md-3" style="margin-bottom:50px">
                    <p><strong>Editar Titulo</strong></p>
                    <input class="form-control" name="name" type="text" placeholder="Nombre del Curso" value="<?php echo e($post->name); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group col-md-12">
                    <div class="form-group col-md-6 p-0">
                        <div class="form-group col-md-12  p-0 m-0">
                            <p><strong>Editar Post</strong></p>
                            <textarea id="editor" name="body" placeholder="Escribe tu Post..." rows="10" cols="20">
                                    <?php echo e($post->body); ?>

                            </textarea>
                                
                            <script>

                                CKEDITOR.replace( 'editor', {
                                });
                                CKEDITOR.config.toolbar = 'full';
                                CKEDITOR.plugins.addExternal( 'youtube', 'plugins/youtube/youtube/plugin.js' );
                                CKFinder.setupCKEditor();
                                CKEDITOR.config.height = 400;

                            </script>
                        </div> 

                    </div>
                    <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group col-md-6" style="margin-bottom:100px">
                    <p><strong>Seleccioná una categoría</strong></p>
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="float-left" style="width:125px">
                        <label class="m-auto" for="<?php echo e($categoria->name); ?>">
                            <input id="<?php echo e($categoria->name); ?>" class="mb-1 mr-1" type="radio" name="category" value="<?php echo e($categoria->id); ?>" <?php if($post->category->id == $categoria->id): ?> <?php echo e("checked=checked"); ?> <?php endif; ?> >
                            <?php echo e($categoria->name); ?>

                        </label>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="form-group col-md-3">
                    <button class="btn btn-primary" type="submit">Editar</button>
                </div>
            </form>
        </div>
    </body>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/posts/edit.blade.php ENDPATH**/ ?>