<div>
    
    <div class="row col-md-12 m-0 mb-3 d-flex justify-content-center">
        <!-- Search -->
        <form class="col-md-7 col-lg-6 col-xl-4 mb-5 mt-3 d-flex justify-content-center" wire:submit.prevent="filtrarSearch">
            <input class="input-text" wire:model="search" type="text" placeholder="Buscá por título" >
        </form>
    </div>

    <!-- Dropdown Menu Filtros -->
    <div class="row col-md-12 m-0 mb-3 d-flex justify-content-center">
    
        <div class="hidden sm:flex col-md-12 p-0">
            <!-- Settings Dropdown -->
            <div class="relative col-md-12 p-0 d-flex justify-content-center">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dropdown_para_search','data' => ['align' => 'right','width' => '100']]); ?>
<?php $component->withName('dropdown_para_search'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['align' => 'right','width' => '100']); ?>
                     <?php $__env->slot('trigger'); ?> 
                            <span class="inline-flex rounded-md">
                                <button type="button" class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 bg-white hover:text-gray-700 focus:outline-none transition ease-in-out duration-150">
                                    Más Filtros
                                    <svg class="ml-2 -mr-0.5 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                    </svg>
                                </button>
                            </span>
                     <?php $__env->endSlot(); ?>
                     <?php $__env->slot('content'); ?> 
                        <!-- Account Management -->
                        <div class="block px-4 py-2 text-xs text-gray-400">
                            Filtros
                        </div>
                        
                        <div class="row col-md-12 m-0 mb-5 d-flex justify-content-center">

        
                                <!-- Fecha -->
                                <div class="col-md-3" style=""> 
                                    <p class="text-center"><strong>Fecha</strong></p>

                                    <div class="d-flex justify-content-center">
                                        <button type="submit" wire:click="filtrarFecha('desc')"><p style="margin:0;padding:0"><p style="margin:0px" <?php if($fecha == 'desc'): ?> <?php echo e("class=font-weight-bold"); ?>  <?php endif; ?>>Más recientes</p></button>
                                    </div>
                                    <div class="d-flex justify-content-center">
                                        <button type="submit" wire:click="filtrarFecha('asc')"><p style="margin:0;padding:0">
                                            <?php if($fecha == 'asc'): ?>
                                                <p style="margin:0px" class=font-weight-bold>Más antiguos x</p>
                                            <?php else: ?> 
                                                <p style="margin:0px">Más antiguos</p>
                                            <?php endif; ?>
                                        </button>
                                    </div>
                                    
                                </div>

                                <!-- Categorías -->
                                <div class="col-md-3" style=""> 
                                    <p class="text-center mr-5"><strong>Categoría</strong></p>
                                    <div class="row float-left" style="width: 100%">
                                        <?php $cantidad_categorias = sizeof($categorias); ?>
                                        <div class="col-md-7">
                                            <?php for($i = 0; ceil($i<$cantidad_categorias/2); $i++): ?>
                                                <div>
                                                    <button type="submit" wire:click="filtrarCategoria('<?php echo e($categorias[$i]->name); ?>')"><p style="margin:0;padding:0">
                                                        <?php if($categoria==$categorias[$i]->name): ?>
                                                            <p style="margin:0px" class=font-weight-bold><?php echo e($categorias[$i]->name); ?> x</p>
                                                        <?php else: ?> 
                                                            <p style="margin:0px"><?php echo e($categorias[$i]->name); ?></p>
                                                        <?php endif; ?>
                                                    </button>
                                                </div>
                                            <?php endfor; ?>
                                        </div>
                                        <div class="col-md-5">
                                            <?php for($i = ceil($cantidad_categorias/2); $i<$cantidad_categorias; $i++): ?>
                                                <button type="submit" wire:click="filtrarCategoria('<?php echo e($categorias[$i]->name); ?>')">
                                                    <?php if($categoria==$categorias[$i]->name): ?>
                                                        <p style="margin:0px" class=font-weight-bold><?php echo e($categorias[$i]->name); ?> x</p>
                                                    <?php else: ?> 
                                                        <p style="margin:0px"><?php echo e($categorias[$i]->name); ?></p>
                                                    <?php endif; ?>     
                                                </button>
                                            <?php endfor; ?>
                                        </div>
                                    </div>
                                </div>

                                <!-- Likes -->
                                <div class="col-md-3" style=""> 
                                    <p class="text-center"><strong>Valoración</strong></p>
                                    <div class="" style="width: 100%">
                                        <div class="">
                                            <button type="submit" style="display:block;margin:auto" wire:click="filtrarValoracion('desc')">
                                                <?php if($valoracion == 'desc'): ?> 
                                                    <p style="margin:0px"  class=font-weight-bold>Más Valorados x</p> 
                                                <?php else: ?> 
                                                    <p style="margin:0px" >Más Valorados</p>
                                                <?php endif; ?>
                                            </button>
                                        </div> 
                                        <div class="">
                                            <button type="submit" style="display:block;margin:auto"  wire:click="filtrarValoracion('asc')">
                                                <?php if($valoracion == 'asc'): ?>
                                                    <p style="margin:0px"  class=font-weight-bold>Menos Valorados x</p> 
                                                <?php else: ?> 
                                                    <p style="margin:0px" >Menos Valorados</p>
                                                <?php endif; ?>
                                            </button>
                                        </div> 
                                    </div>
                                </div>

                         

                     <?php $__env->endSlot(); ?>
                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
  

</div>

<!-- Resultados --> 

<div class="" style="margin-bottom:50px;width:65%;margin:auto">


    <div class="row">
        
        <?php if(sizeof($posts)>0): ?>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="post col-xs-12 col-sm-12 col-md-6 col-lg-4 mb-4" style="display:flex;align-items: center">
                    <a href="<?php echo e(route('posts.show', [$post->id, $post->name])); ?>" style="color:white">
                        <div class="" style="position:relative; width:100%;">
                            <img src="<?php echo e($post->image->url); ?>" style="border-radius:8px; width: 100%;height:100%;object-fit: cover;" alt="">
                            <div class="card-title text-center m-0" style="text-overflow: ellipsis;overflow: hidden;display:flex;align-items:center;border-radius:0px 0px 8px 8px;width:100%;height:31%;background-color: rgba(0, 0, 0, 0.5);position:absolute;bottom:0px;left:0px"><p class="m-auto text-overflow: ellipsis;overflow: hidden;"><?php echo e($post->name); ?></p></div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php elseif(1==0): ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="post col-md-4 col-sm-12 mb-4" style="display:flex;align-items: center;width:30%">
                    <a href="<?php echo e(route('user.posts', $user->id)); ?>" style="color:white">
                        <div class="" style="position:relative; width:100%;">
                            <!--<img src="" style="border-radius:8px; width: 100%;height:100%;object-fit: cover;" alt="">-->
                            <div class="card-title text-center m-0" style="border-radius:0px 0px 8px 8px;width:100%;height:31%;background-color: rgba(0, 0, 0, 0.5);position:absolute;bottom:0px;left:0px"><p><?php echo e($user->name); ?></p></div>
                        </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php elseif(sizeof($posts)==0): ?>

            <div class="mx-auto mt-5">
                <p class="text-center">
                    No se encontraron resultados
                </p>
            </div>
            
        <?php endif; ?>

    </div>
    <hr style="border:1px solid; color:rgba(207, 207, 207, 0.486)"><br>


    <!-- Paginado -->

    <button wire:click="pagina('anterior')" class="relative inline-flex items-center px-4 py-2 text-sm font-medium text-gray-500 <?php if($offset==0): ?> <?php echo e('off'); ?> <?php else: ?> <?php echo e("bg-white"); ?>  <?php endif; ?> border border-gray-300 cursor-default leading-5 rounded-md focus:outline-none focus:ring ring-gray-300"
    type="submit"  
    <?php if($offset==0): ?> <?php echo e('disabled'); ?> <?php endif; ?>>
    « Previous    
    </button>

    <button  wire:click="pagina('siguiente')" id="button_siguiente" class="relative inline-flex items-center px-4 py-2 ml-3 text-sm font-medium text-gray-700 <?php if($disabled==true): ?> <?php echo e('off'); ?> <?php else: ?> <?php echo e("bg-white"); ?> <?php endif; ?>  border border-gray-300 leading-5 rounded-md hover:text-gray-500 focus:outline-none focus:ring ring-gray-300 focus:border-blue-300 active:bg-gray-100 active:text-gray-700 transition ease-in-out duration-150"
    type="submit" 
    <?php if($disabled==true): ?> <?php echo e('disabled'); ?> <?php endif; ?>>
    Next »
    </button>

</div>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/livewire/buscador.blade.php ENDPATH**/ ?>