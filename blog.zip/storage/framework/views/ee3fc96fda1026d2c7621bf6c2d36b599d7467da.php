<div>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <strong><?php echo e($title); ?></strong> <?php echo e($slot); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
</div><?php /**PATH C:\xampp\htdocs\blog\resources\views/components/alert2.blade.php ENDPATH**/ ?>