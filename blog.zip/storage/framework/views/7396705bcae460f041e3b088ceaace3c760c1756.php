<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-1">
        <div class="max-w-9xl mx-auto sm:px-6 lg:px-8" style="padding-left:20%;padding-right:20%;padding-top:30px;padding-bottom:40px;background-color:white">
            
            <div style="margin-bottom:40px">
                <h3>Favoritos: </h3>
            </div>

                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  

                <a class="" href="<?php echo e(route('posts.show', [$post->id, $post->name])); ?>">
                    <div class="col mb-1" style="overflow:hidden">

                            <div style="float:left;width:100%;margin-right:30px">

                                <!-- Cover -->
                                <div style="float:left;margin-right:30px"><img src="<?php echo e($post->image->url); ?>" style="width:140px;border-radius:5px;"></div>
                                <div class="d-flex justify-content-center" style="float:left;margin-top:30px"><p><?php echo e($post->name); ?></p></div>

                            </div>
                    </div>
                    <hr>
                </a>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
                <?php echo e($posts->links()); ?>


        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    <script>
    $(".formulario-eliminar").submit(function(e){
        e.preventDefault();

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
            Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
            )
            this.submit();
            }

        })      

    });

    </script><?php /**PATH C:\xampp\htdocs\blog\resources\views/user/favoritos.blade.php ENDPATH**/ ?>