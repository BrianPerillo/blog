<?php return array (
  'buscador' => 'App\\Http\\Livewire\\Buscador',
  'chat-form' => 'App\\Http\\Livewire\\ChatForm',
  'like-component' => 'App\\Http\\Livewire\\LikeComponent',
);